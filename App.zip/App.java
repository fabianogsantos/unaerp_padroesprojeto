package br.unaerp.padroesprojeto;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.unaerp.padroesprojeto.ResultSetPrinter;

public class App {

	public static void main(String[] args) throws SQLException {
		
		ResultSetPrinter rsp = new ResultSetPrinter();
		
		ContatoDAO dao = new ContatoDAO();
		
		ResultSet contatos = dao.getAll();
		
		rsp.printResultSet(contatos);
		
		
		
	}

}
